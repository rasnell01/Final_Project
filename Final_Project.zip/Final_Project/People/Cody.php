<?php
    define("TITLE", "Cody SMASH!");
?>

<!DOCTYPE>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo TITLE; ?></title>

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <link rel="stylesheet" href="../CSS/styles.css" type="text/css">
        
        <!-- file links -->
        <link href="Index.html">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <header>
            <div>
                <ul>
                    <li class="headerMenu"><a href="../PHP/home.php">Home</a></li>
                    <li class="headerMenu"><a href="Miguel.php">Meet Miguel</a></li>
                    <li class="headerMenu"><a href="Josh.php">Meet Josh</a></li>
                    <li class="headerMenu"><a href="Ryan.php">Meet Ryan</a></li>
                </ul>
            </div>
        </header>
        <main>
            <h3 id="codyMainH3"><?php echo TITLE; ?></h3>
            <div id="codyMainDiv">
                <a><img src="../images/Hulk_(comics_character).png"/></a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In neque libero, bibendum sed rhoncus eu, aliquet sed lacus. Phasellus non tempor erat. Nullam ultrices commodo laoreet. Sed eleifend imperdiet massa eu ornare. Mauris ut sem vitae nisi finibus semper. Curabitur vitae aliquam ligula, quis facilisis elit. Pellentesque imperdiet ipsum eu pretium eleifend. Aliquam erat volutpat. Cras sollicitudin diam in imperdiet congue. Maecenas in lorem sem.

                Sed sed congue leo. Donec tempus orci dui, nec rhoncus diam auctor sit amet. Praesent a felis lacus. Donec ut bibendum ipsum. Sed mi mi, fringilla at est et, ultrices ultricies ligula. Maecenas id mauris justo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Mauris at pulvinar turpis. Nam in rutrum mi. Pellentesque ante erat, malesuada ac purus et, tincidunt rhoncus turpis. Vivamus ut volutpat purus, sed pellentesque arcu. Sed dapibus mauris nunc, sed vestibulum ante consequat sed. Aenean sit amet ante finibus, bibendum odio aliquet, consequat mi. Proin tempus mi sed neque viverra, quis ultricies sapien rutrum. Aliquam erat volutpat. Proin sed orci a tellus tincidunt vestibulum et at lacus.</p>
            </div>
        </main>
        <footer>
            <div class="footerContainerOne">
                <ul class="footerMenu">
                    <li class="footerMenu"><a href="../PHP/home.php">Home</a></li>
                    <li class="footerMenu"><a href="../PHP/contact.php">Contact</a></li>
                    <li class="footerMenu"><a href="../PHP/about.php">About</a></li>
                </ul>
            </div>
            <div class="footerContainerTwo">
                <ul class="subscribe">
                    <li class="subscribe"><a href="https://www.facebook.com/sharer/sharer.php?u=Final_Project_Whateva_Whateva" target="_blank">Share on Facebook</a></li>
                    <li class="subscribe"><a href="https://twitter.com/home?status=Final_Project_Whateva_Whateva" target="_blank">Share on Twitter</a></li>
                    <li class="subscribe"><a href="https://www.instagram.com/home?status=Final_Project_Whateva_Whatevan" target="_blank">Share on Instagram</a></li>
                    <li class="subscribe"><a href="https://www.snapchat.com/?status=Final_Project_Whateva_Whateva" target="_blank">Share on SnapChat</a></li>
                </ul>
            </div>
            <div class="copyright">
                <h6>Team whateva whateva &copy; 2019.</h6>
            </div>
        </footer>
    </body>
        <!-- jQuery -->
        <script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
        
        <!-- Bootstrap JS -->
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</html>