<?php
    define("TITLE", "Contact US");
    include 'connection.php';
        
    if( isset( $_POST["add"] ) ) {
        
    // build a function that validates data
    function validateFormData( $formData ) {
        $formData = trim( stripslashes( htmlspecialchars( $formData ) ) );
        return $formData;
    }
        
        //checking fname
        if(!$_POST["fname"] ) {
            $fnameError = "Please enter your first name. <br>";
        } else {
            $fname = validateFormData( $_POST["fname"] );
        }
        //checking lname
        if(!$_POST["lname"] ) {
            $lnameError = "Please enter your last name. <br>";
        } else {
            $lname = validateFormData( $_POST["lname"] );
        }
        //checking email
        if(!$_POST["email"] ) {
            $emailError = "Please enter your name. <br>";
        } else {
            $email = validateFormData( $_POST["email"] );
        }
        //checking gender
        if(!$_POST["gender"] ) {
            $genderError = "Please select a gender. <br>";
        } else {
            $gender = validateFormData( $_POST["gender"] );
        }
        //checking bday
        if(!$_POST["bday"] ) {
            $bdayError = "Please enter your name. <br>";
        } else {
            $bday = validateFormData( $_POST["bday"] );
        }
        
        if( $fname && $lname && $email && $gender && $bday ) {
    $query = "INSERT INTO contacts (id, fname, lname, email, gender, bday, signUpDate)
    VALUE (NULL, '$fname', '$lname', '$email', '$gender', '$bday', NULL)";
        
            if(mysqli_query($conn, $query)) {
                echo "<div class='alert alert-success'>New record in database!</div>";
            } else {
                echo "Error: " . $query . "<br>" . mysqli_error($conn);
            }
        }
    }
    
mysqli_close($conn);

?>
<!DOCTYPE>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo TITLE; ?></title>

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <link rel="stylesheet" href="../CSS/styles.css" type="text/css">
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <header>
            <h1>Contact Us</h1>
            <div>
                <h3><a href="../PHP/home.php">Home</a></h3>
            </div>
        </header>
        <main>
            <div id="contactForm">
               
               <p class="text-danger">* Required Fields</p>
                <form action="<?php echo htmlspecialchars( $_SERVER['PHP_SELF'] ); ?>" method="post">
                   
                    <!-- first name -->
                    <small class="text-danger">* <?php echo $fnameError; ?></small>
                    <input type="text" placeholder="First Name" name="fname" /><br><br>
                    
                    <!-- last name -->
                    <small class="text-danger">* <?php echo $lnameError; ?></small>
                    <input type="text" placeholder="Last Name" name="lname" /><br><br>
                    
                    <!-- email address -->
                    <small class="text-danger">* <?php echo $emailError; ?></small>
                    <input type="text" placeholder="Email Address" name="email" /><br><br>
                    
                    <!-- gender select -->
                    <small class="text-danger">* <?php echo $genderError; ?></small><br>
                    Gender: <br><input type="radio" name="gender" value="male" checked> Male<br>
                    <input type="radio" name="gender" value="female"> Female<br>
                    <br>
                    
                    <!-- birthdate select -->
                    <small class="text-danger">* <?php echo $bdayError; ?></small>
                    Birthday: <br><input type="date" name="bday"><br><br>
                    
                    <input class="btn btn-primary btn-md pull-left" type="submit" name="add" value="Add Entry">
                    
                </form>
            </div>
            <div>
                
            </div>
        </main>
        <footer>
            <div class="copyright">
                <h6>Team whateva whateva &copy; 2019.</h6>
            </div>
        </footer>
    </body>
        <!-- jQuery -->
        <script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
        
        <!-- Bootstrap JS -->
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</html>