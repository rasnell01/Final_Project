<?php
//connection information
$server  ="localhost";
$user   ="root";
$pass   ="root";
$db     ="teamWhatevaWhateva";

// Create a connaction
$conn = mysqli_connect( $server, $user, $pass, $db );

//Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>