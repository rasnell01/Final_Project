<?php
    define("TITLE", "About Us");
?>
<!DOCTYPE>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo TITLE; ?></title>

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <link rel="stylesheet" href="../CSS/styles.css" type="text/css">
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <header>
            <h1><?php echo TITLE;?></h1>
            <div>
                <h3><a href="../PHP/home.php">Home</a></h3>
            </div>
        </header>
        <main>
            <div>
                <h4>This is what we like!</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam porta et metus eu dictum. Duis ut libero ac odio congue varius. Sed euismod porta feugiat. Aenean vitae arcu at est lacinia fringilla ac sed sem. Etiam eu risus tellus. Sed iaculis est in eros dignissim, vitae facilisis lacus suscipit. Fusce fermentum massa vel condimentum sodales. Duis vitae odio quis eros vulputate ultrices at id elit. Aliquam erat volutpat. Donec non lectus dolor. Sed ac vehicula lacus, eu malesuada ex. Etiam scelerisque felis non purus convallis, eget feugiat urna elementum. Sed a ligula eget lacus luctus vehicula at sed mauris. Mauris vel auctor magna, sit amet imperdiet sem. Morbi malesuada feugiat sollicitudin. Fusce interdum augue venenatis maximus convallis.

                Integer velit ligula, facilisis non nibh vel, ullamcorper suscipit justo. Ut nec lacus id urna tincidunt ullamcorper quis posuere orci. Cras vitae mauris a ante ullamcorper lobortis. Proin quis nulla efficitur, auctor ligula eu, rutrum arcu. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam efficitur nisi sit amet massa faucibus consequat at vel nunc. Morbi sed fringilla urna. Sed at neque lectus. Etiam hendrerit, arcu at blandit ullamcorper, lorem neque pharetra nulla, sit amet rhoncus velit lacus in ligula. Maecenas eget mi id mi malesuada consequat ac quis erat. Nullam volutpat mi quis neque ornare dapibus. Nam ut sagittis erat, eu tempus tortor. Aliquam consectetur pretium arcu vitae finibus. Nullam sodales metus vitae fringilla mattis. Vestibulum fermentum urna in dui suscipit hendrerit.

                Mauris sit amet ultrices nisl. Quisque vitae velit pellentesque, egestas nunc id, ornare lorem. Integer fermentum est quam, quis aliquet velit volutpat ac. Suspendisse tellus felis, lacinia et ligula nec, pulvinar commodo risus. Maecenas a metus mattis, cursus lorem et, laoreet libero. Proin rutrum pretium dui, at vehicula odio efficitur quis. Donec malesuada et sem in pulvinar. Integer condimentum sem tellus, vel faucibus turpis bibendum ut.

                Quisque consectetur ligula eget odio accumsan, sit amet ultrices magna luctus. Fusce et dolor ut sapien finibus sagittis vitae id felis. Donec non porttitor quam. Sed est felis, maximus in massa eget, faucibus laoreet neque. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum accumsan aliquet faucibus. Phasellus rhoncus placerat eros, ut malesuada nibh pellentesque id. Donec dictum dictum dui, accumsan aliquet nulla cursus in. Nulla pretium velit at dictum consectetur.

                Nulla mattis risus sed rutrum lacinia. Pellentesque posuere nibh a diam pharetra rhoncus. Cras auctor ipsum a metus condimentum rhoncus. Duis pellentesque turpis metus, eget tempor ligula interdum ac. Suspendisse sodales non metus tempus sodales. Vivamus faucibus rutrum sem, in posuere felis sagittis et. Morbi finibus mauris eget turpis bibendum, quis fermentum mi pharetra.

                Praesent tristique justo ut venenatis sollicitudin. Nunc aliquet sapien lorem. Sed commodo, eros sed elementum rhoncus, tortor orci lobortis lorem, in pretium lectus arcu sed sem. Nullam nulla tortor, tincidunt nec diam quis, posuere vulputate lacus. Sed sit amet odio vel arcu mollis imperdiet. Praesent sit amet orci leo. Praesent ut volutpat mi, vitae rhoncus sapien. Cras bibendum porttitor porttitor. Vestibulum nec elit tincidunt, posuere dolor a, sagittis dui. Sed placerat lorem ut suscipit rhoncus. Mauris pretium maximus odio. Nunc sit amet faucibus nulla. Nulla feugiat egestas felis congue dapibus. Donec molestie rhoncus odio, ac fermentum nunc ultrices eu.

                Ut in viverra felis, quis elementum dui. Etiam iaculis ligula vel turpis feugiat, sed finibus turpis vulputate. In facilisis sapien sit amet augue efficitur, vel porttitor felis tincidunt. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin scelerisque mauris non placerat consequat. Suspendisse cursus velit non dolor commodo, quis dignissim massa sagittis. Integer suscipit sagittis ipsum, eget elementum ante fringilla vitae. Cras id velit elementum, iaculis purus quis, lobortis leo. Aliquam vulputate porttitor nulla, vitae pellentesque urna auctor ac. Nam eleifend suscipit consequat. Mauris vitae imperdiet massa. Pellentesque malesuada a urna a mattis. Ut ultricies vehicula ornare. Fusce interdum, nibh eu molestie tincidunt, sem elit congue odio, a suscipit orci ex sit amet ex. Quisque sed velit ac dolor molestie lobortis.

                Donec nec elit ut justo congue tristique quis a orci. Etiam eu ex in dolor dignissim faucibus. Nullam nibh magna, dignissim eget justo sit amet, gravida interdum quam. Donec et luctus tortor. Aenean nec orci non leo egestas blandit et non arcu. Donec et sem sit amet purus dictum commodo. Sed in est libero. Nullam quis risus fermentum, luctus velit ac, malesuada purus.

                Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras et lacus orci. Pellentesque in interdum sem, quis tempus nunc. Nulla at nisl felis. Etiam eu odio leo. Nam posuere nisi eget semper luctus. Aenean ut fermentum odio. Sed blandit commodo magna eu sollicitudin. Maecenas interdum rutrum ante a eleifend. Sed ultrices massa non lorem aliquet iaculis. Ut fringilla lacus diam, facilisis ullamcorper felis vestibulum sit amet. Nunc dignissim ac arcu et hendrerit.

                Sed lacus nisl, malesuada ac pellentesque vel, porttitor et odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent a ante suscipit, ullamcorper nisl non, aliquam ante. Donec vestibulum nunc nec est gravida gravida. Praesent commodo lacus et dui ornare finibus. Suspendisse sollicitudin sit amet neque sed posuere. Ut id ligula nec tortor interdum malesuada ut in tellus. Ut semper leo faucibus leo congue, nec laoreet neque viverra. Vivamus et pulvinar urna. Etiam tincidunt metus venenatis porta porta. Proin iaculis condimentum est, et semper leo tristique at. Suspendisse aliquam rhoncus mi eget rutrum. Etiam fermentum orci nec rutrum lobortis. Proin id nibh at tellus malesuada feugiat sed vel nisi. Cras commodo in purus a egestas. Etiam euismod sit amet odio ac aliquam.

                Nullam ac lectus vitae turpis dignissim iaculis. Sed elementum sit amet nulla at scelerisque. Pellentesque tortor dolor, interdum id finibus ac, tincidunt id mi. Sed sit amet ligula metus. Pellentesque imperdiet turpis nunc, eu dictum nibh mollis ut. In finibus quam vitae finibus suscipit. Cras faucibus urna mollis erat pharetra hendrerit. Maecenas ante ipsum, rutrum ac euismod sed, tincidunt sagittis orci. Aliquam a erat ut turpis rhoncus interdum. Etiam et mauris suscipit, dictum nulla sit amet, suscipit dolor. Donec orci ipsum, malesuada vitae lectus vel, commodo posuere lorem. Sed tincidunt gravida lobortis. Mauris in tincidunt sem. Curabitur efficitur consectetur ante sit amet ultrices. Sed non ornare metus.

                Curabitur quis cursus diam. Sed rhoncus euismod nisi feugiat fermentum. Pellentesque leo ligula, mollis ut efficitur vitae, varius sit amet quam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius magna vitae metus venenatis mattis. Vestibulum posuere, est eget ornare facilisis, nulla enim accumsan libero, dignissim rutrum massa neque ut massa. Pellentesque dapibus quam a massa mollis, sit amet interdum dolor laoreet. Sed odio elit, lobortis eget hendrerit mattis, porta eget nulla.</p>
            </div>
        </main>
        <footer>
            <div class="copyright">
                <h6>Team whateva whateva &copy; 2019.</h6>
            </div>
        </footer>
    </body>
        <!-- jQuery -->
        <script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
        
        <!-- Bootstrap JS -->
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</html>